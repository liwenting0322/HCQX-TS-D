
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'v0.2' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32g4xx.h"

#define RTE_DEVICE_CUBE_MX_HAL
#define RTE_DEVICE_FRAMEWORK_CUBE_MX

#endif /* RTE_COMPONENTS_H */
