#ifndef  _ADINIT_H
#define  _ADINIT_H

#include "ad7124.h"



#define SPI1_CS_PIN  GPIO_PIN_4
#define SPI1_PORT	 GPIOA
#define SPI1_CS_H    HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_SET)
#define SPI1_CS_L  	 HAL_GPIO_WritePin(GPIOA,GPIO_PIN_4,GPIO_PIN_RESET)




void SPI1_CS_Init(void);








#endif

